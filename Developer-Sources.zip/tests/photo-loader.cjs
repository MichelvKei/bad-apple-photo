const assert=require('node:assert/strict'),Loader=require('../dist/photo-loader.js');
(async()=>{
 const jobs=[],shown=[],errors=[],closed=[];
 const loader=new Loader(file=>new Promise((resolve,reject)=>jobs.push({file,resolve,reject})),(im,file)=>shown.push(file),e=>errors.push(e));
 const flush=()=>new Promise(r=>setImmediate(r));
 loader.select('A');loader.select('B');loader.select('C');
 assert.deepEqual(jobs.map(j=>j.file),['A']);
 jobs[0].resolve({close:()=>closed.push('A')});await flush();
 assert.deepEqual(jobs.map(j=>j.file),['A','C']);assert.deepEqual(closed,['A']);assert.deepEqual(shown,[]);
 jobs[1].resolve({});await flush();assert.deepEqual(shown,['C']);
 loader.select('D');loader.cancel();jobs[2].reject(Error('stale'));await flush();assert.equal(errors.length,0);
 loader.select('E');jobs[3].reject(Error('bad image'));await flush();assert.equal(errors.length,1);
 loader.select('F');jobs[4].resolve({});await flush();assert.deepEqual(shown,['C','F']);
 console.log('PASS: latest selection wins, superseded decode skipped, stale image released, cancellation and error recovery');
})();
