const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),vm=require('node:vm');
const root=path.resolve(__dirname,'../dist');
const context={console,Uint16Array,Float32Array,Uint8ClampedArray,DataView,Map,Set,Promise,Math,Error,Response,DecompressionStream,window:{DecompressionStream},
 fetch:async url=>new Response(fs.readFileSync(path.join(root,url))),
 document:{createElement:()=>({getContext:()=>({createImageData:(w,h)=>({data:new Uint8ClampedArray(w*h*4)}),putImageData:()=>{}})})}};
vm.createContext(context);vm.runInContext(fs.readFileSync(path.join(root,'motion.js'),'utf8')+'\nglobalThis.Motion=BAMotion;',context);
(async()=>{
const motion=new context.Motion(()=>{});await motion.readyForExport();
assert.equal(motion.chunks.size,motion.meta.chunks.length);
const photo=new Uint8ClampedArray(640*480*4);for(let y=0;y<480;y++)for(let x=0;x<640;x++){let i=(y*640+x)*4;photo[i]=x%256;photo[i+1]=y%256;photo[i+2]=100;photo[i+3]=255}
motion.setPhoto({getContext:()=>({getImageData:()=>({data:photo})})});
const target={drawImage:()=>{}},box={x:0,y:0,width:640,height:480};
assert(motion.draw(target,box,8,0));const identity=motion.output.data.slice();assert.equal(motion.anchorPosition.x,.5);assert.equal(motion.anchorPosition.y,.5);
assert(motion.draw(target,box,8,1));const warped=motion.output.data.slice();
let changed=0;for(let i=0;i<warped.length;i+=4)if(Math.abs(warped[i]-identity[i])>5||Math.abs(warped[i+1]-identity[i+1])>5)changed++;
assert(changed>10000,'Local mode must visibly differ from whole-image mapping');
motion.draw(target,box,6,1);motion.draw(target,box,8,1);assert.deepEqual(motion.output.data,warped,'Seeking must be deterministic');
assert(motion.draw(target,box,219.08,1));
console.log(`PASS: ${motion.chunks.size} chunks decoded; ${changed} pixels locally changed; seeking deterministic; final frame safe`);
})().catch(e=>{console.error(e);process.exitCode=1});
