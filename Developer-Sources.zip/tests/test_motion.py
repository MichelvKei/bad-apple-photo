import importlib.util, pathlib, numpy as np, cv2
p=pathlib.Path(__file__).resolve().parents[1]/'scripts/build-motion.py'
spec=importlib.util.spec_from_file_location('motion',p);motion=importlib.util.module_from_spec(spec);spec.loader.exec_module(motion)

def arm(angle):
    m=np.zeros((120,160),np.uint8)
    cv2.rectangle(m,(55,45),(78,110),255,-1)
    cv2.circle(m,(66,31),15,255,-1)
    tip=(round(76+49*np.cos(angle)),round(55+49*np.sin(angle)))
    cv2.line(m,(73,55),tip,255,12);cv2.circle(m,tip,6,255,-1)
    return m,tip
prev,first=arm(0);uv=motion.IDENTITY.copy()
for a in np.linspace(0,-1.0,41)[1:]:
    cur,tip=arm(a);uv,_=motion.transport(motion.feature(prev),motion.feature(cur),uv);prev=cur
expected=np.array([first[0]/159,first[1]/119]);actual=uv[tip[1],tip[0]]
static=np.array([tip[0]/159,tip[1]/119]);tracked_error=np.linalg.norm(actual-expected);static_error=np.linalg.norm(static-expected)
# A lifted hand should retain substantially more of its original patch than a stationary UV field.
print({'tracked_hand_uv_error':float(tracked_error),'stationary_uv_error':float(static_error),'reduction':float(1-tracked_error/static_error)})
assert tracked_error<static_error*.65
ys,xs=np.where(cur>127);xy=np.column_stack([xs/159,ys/119,np.ones(len(xs))]);values=uv[ys,xs]
fit=np.linalg.lstsq(xy,values,rcond=None)[0];residual=np.sqrt(np.mean((xy@fit-values)**2))
print({'non_affine_uv_residual':float(residual)})
assert residual>.005,'Field must include local deformation, not just a whole-image affine transform'
assert np.all(np.isfinite(uv))
print('PASS: moving hand retains its texture; deformation is non-affine; finite UVs')
