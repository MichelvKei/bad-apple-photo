const assert=require('node:assert/strict');
const {crop,bounds}=require('../dist/tracking.js');
function mask(w,h,rect){const d=new Uint8ClampedArray(w*h*4).fill(255);if(rect)for(let y=rect.y;y<rect.y+rect.height;y++)for(let x=rect.x;x<rect.x+rect.width;x++){const i=(y*w+x)*4;d[i]=d[i+1]=d[i+2]=0}return d}
const first=bounds(mask(640,480,{x:100,y:60,width:120,height:200}),640,480);
const moved=bounds(mask(640,480,{x:260,y:100,width:120,height:200}),640,480);
assert.equal(moved.x-first.x,160);assert.equal(moved.y-first.y,40);
assert.equal(moved.width,first.width);assert.equal(moved.height,first.height);
const bigger=bounds(mask(640,480,{x:100,y:60,width:240,height:300}),640,480);
assert(bigger.width>first.width&&bigger.height>first.height);
assert.equal(bounds(mask(640,480),640,480),null);
const specks=mask(640,480,{x:100,y:60,width:120,height:200});specks[0]=specks[1]=specks[2]=0;
assert.deepEqual(bounds(specks,640,480),first);
for(const [w,h] of [[1200,800],[800,1200]])for(const x of [0,.25,.5,1])for(const y of [0,.5,1]){
const c=crop(w,h,2,x,y);assert(c.x>=0&&c.y>=0&&c.x+c.width<=w+.001&&c.y+c.height<=h+.001);
assert.equal(c.cx,c.x+c.width/2);assert.equal(c.cy,c.y+c.height/2);
}
assert(crop(1200,800,3,.5,.5).width<crop(1200,800,1.5,.5,.5).width);
console.log('PASS: translation, scale, blank frame, speck rejection, portrait/landscape edge anchors, fixed crop zoom');
