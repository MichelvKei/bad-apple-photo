"""Make a self-contained HTML plus a clean, provider-neutral deployment ZIP."""
from pathlib import Path
import base64,json,zipfile
root=Path(__file__).resolve().parents[1];dist=root/'dist';out=root.parent/'BadApple-分享包';out.mkdir(exist_ok=True)
html=(dist/'index.html').read_text()
html=html.replace('<link rel="stylesheet" href="style.css">','<style>'+(dist/'style.css').read_text()+'</style>')
html=html.replace(' src="mask.mp4"','')
assets={str(p.relative_to(dist)):base64.b64encode(p.read_bytes()).decode() for p in (dist/'motion').iterdir() if p.is_file()}
assets['mask.mp4']=base64.b64encode((dist/'mask.mp4').read_bytes()).decode()
loader='''const embeddedAssets=ASSETS;
function embeddedBytes(name){const text=atob(embeddedAssets[name]);const bytes=new Uint8Array(text.length);for(let i=0;i<text.length;i++)bytes[i]=text.charCodeAt(i);return bytes}
function offlineFetch(name){if(!Object.hasOwn(embeddedAssets,name))return Promise.reject(new Error('Missing embedded asset'));return Promise.resolve(new Response(embeddedBytes(name)))}
document.getElementById('source').src=URL.createObjectURL(new Blob([embeddedBytes('mask.mp4')],{type:'video/mp4'}));
'''.replace('ASSETS',json.dumps(assets,separators=(',',':')))
html=html.replace('<script src="tracking.js"></script>','<script>'+(dist/'tracking.js').read_text()+'</script>')
html=html.replace('<script src="motion.js"></script>','<script>'+loader+(dist/'motion.js').read_text().replace('fetch(', 'offlineFetch(')+'</script>')
html=html.replace('<script src="photo-loader.js"></script>','<script>'+(dist/'photo-loader.js').read_text()+'</script>')
html=html.replace('<script src="app.js"></script>','<script>'+(dist/'app.js').read_text()+'</script>')
html=html.replace('href="./" aria-label=', 'href="#" aria-label=')
html=html.replace('照片很正常，出来就不一定了。</title>','离线版</title>')
file=out/'BadApple-双击打开.html';file.write_text(html)
with zipfile.ZipFile(out/'BadApple-网站部署包.zip','w',zipfile.ZIP_DEFLATED) as z:
 for p in dist.rglob('*'):
  if p.is_file():z.write(p,p.relative_to(dist))
(out/'使用说明.txt').write_text('Bad Apple 人物转换器\n\n离线玩：把「BadApple-双击打开.html」发给朋友，先下载到电脑，再用 Chrome 或 Edge 打开。无需登录，不访问原来的 chatgpt.site 网站。视频和动作数据都已装进文件。聊天软件内置预览不一定支持，请用完整浏览器。照片只在本机处理。\n\n声音默认 70%，点击「开始发癫」后出声；播放器下方可静音和调音量。浏览器或系统仍可能要求一次点击或调整系统音量。\n\n网站迁移：「BadApple-网站部署包.zip」解压后，index.html 位于根目录。可上传到支持静态文件的网站托管服务，无需构建和后台。不要直接双击部署包中的 index.html；离线使用请打开上面的单文件版。\n\n原网址出现 Sorry you have been blocked 的问题尚未解除。此离线版是不依赖该网址的备用方式，不是原域名国内访问已修复。\n')
print(json.dumps({'offline_file':str(file),'offline_MB':file.stat().st_size/1e6,'deploy_zip':str(out/'BadApple-网站部署包.zip')},ensure_ascii=False))
