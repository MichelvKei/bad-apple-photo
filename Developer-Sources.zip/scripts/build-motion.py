"""Precompute silhouette-local UV transport. Source: OpenCV Farneback optical flow.
https://docs.opencv.org/4.7.0/dc/d6b/group__video__track.html
No photographs or user data are used. Coordinates are anchored per shot.
"""
import cv2, numpy as np, gzip, json, pathlib, time
ROOT=pathlib.Path(__file__).resolve().parents[1]
W,H=160,120
GW,GH=41,31
FPS=15
CHUNK=450
Y,X=np.mgrid[0:H,0:W].astype(np.float32)
IDENTITY=np.dstack((X/(W-1),Y/(H-1)))

def bounds(mask):
    ys,xs=np.where(mask)
    if len(xs)<20:return None
    # Match live bbox's robust tail trimming and edge margin at quarter resolution.
    l,r=np.quantile(xs,[.002,.998]);t,b=np.quantile(ys,[.002,.998])
    l=max(0,int(l)-1);r=min(W-1,int(r)+1);t=max(0,int(t)-1);b=min(H-1,int(b)+1)
    return l,t,r-l+1,b-t+1

def feature(mask):
    a=(mask>127).astype(np.uint8)
    signed=cv2.distanceTransform(a,cv2.DIST_L2,5)-cv2.distanceTransform(1-a,cv2.DIST_L2,5)
    # Distance bands carry contour motion into otherwise featureless black interiors.
    return np.clip(128+signed*6,0,255).astype(np.uint8)

def transport(prev_feature,cur_feature,uv):
    back=cv2.calcOpticalFlowFarneback(cur_feature,prev_feature,None,.5,4,23,4,7,1.5,0)
    mapped=cv2.remap(uv,X+back[:,:,0],Y+back[:,:,1],cv2.INTER_LINEAR,borderMode=cv2.BORDER_REPLICATE)
    # A very weak rest-shape spring limits cumulative squeezing over long shots.
    mapped=mapped*.998+IDENTITY*.002
    return cv2.GaussianBlur(mapped,(3,3),.45),back

def build():
    out=ROOT/'dist/motion';out.mkdir(exist_ok=True)
    cap=cv2.VideoCapture(str(ROOT/'dist/mask.mp4'))
    source_fps=cap.get(cv2.CAP_PROP_FPS);stride=round(source_fps/FPS)
    frame_count=0;selected=0;previous=None;previous_mask=None;uv=IDENTITY.copy();chunks=[];pack=[];cuts=[];start=time.time();stats=[]
    while True:
        ok,frame=cap.read()
        if not ok:break
        frame_count+=1
        if (frame_count-1)%stride:continue
        gray=cv2.resize(cv2.cvtColor(frame,cv2.COLOR_BGR2GRAY),(W,H),interpolation=cv2.INTER_AREA)
        box=bounds(gray<100)
        if box:
            x,y,w,h=box;normalized=cv2.resize((gray[y:y+h,x:x+w]<100).astype(np.uint8)*255,(W,H))
        else:normalized=np.zeros((H,W),np.uint8)
        f=feature(normalized)
        change=1 if previous_mask is None else np.mean((normalized>127)!=(previous_mask>127))
        blank=np.mean(normalized>127)<.005 or np.mean(normalized>127)>.995
        cut=previous is None or blank or change>.32
        if cut:
            uv=IDENTITY.copy();cuts.append(selected)
        else:
            uv,flow=transport(previous,f,uv)
        small=cv2.resize(uv,(GW,GH),interpolation=cv2.INTER_LINEAR)
        encoded=np.rint(np.clip(small,0,1)*65535).astype('<u2')
        pack.append(encoded)
        if selected in [60,90,120,150,180,225,300,450,600,900,1200,1800,2400,3000]:
            np.savez(ROOT/'qa'/f'motion-{selected:04d}.npz',uv=uv,gray=gray,box=np.array(box if box else [0,0,W,H]))
            stats.append({'time':selected/FPS,'mean_offset':float(np.mean(np.abs(uv-IDENTITY))),'cut':bool(cut)})
        previous=f;previous_mask=normalized;selected+=1
        if len(pack)==CHUNK:
            name=f'field-{len(chunks):02d}.bin.gz';payload=np.stack(pack).tobytes();(out/name).write_bytes(gzip.compress(payload,compresslevel=6,mtime=0));chunks.append({'file':name,'frames':len(pack)});pack=[]
            print(f'{selected/FPS:.0f}s analyzed ({time.time()-start:.1f}s elapsed)',flush=True)
    if pack:
        name=f'field-{len(chunks):02d}.bin.gz';(out/name).write_bytes(gzip.compress(np.stack(pack).tobytes(),compresslevel=6,mtime=0));chunks.append({'file':name,'frames':len(pack)})
    manifest={'version':1,'width':GW,'height':GH,'fps':FPS,'frames':selected,'chunkFrames':CHUNK,'chunks':chunks,'cuts':cuts}
    (out/'manifest.json').write_text(json.dumps(manifest,separators=(',',':')))
    (ROOT/'qa/motion-stats.json').write_text(json.dumps(stats,indent=2))
    print(json.dumps({'frames':selected,'chunks':len(chunks),'sizeMB':sum(p.stat().st_size for p in out.iterdir())/1e6,'seconds':time.time()-start}),flush=True)
if __name__=='__main__':build()
